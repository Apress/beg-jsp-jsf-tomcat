To try out the validation examples, place the whole folder xml-validate in webapps.
You can then try, for example, the DTD-validation with SAX by typing in your browser
  http://localhost:8080/xml-validate/with-dtd/starfleet_validate_sax.jsp
