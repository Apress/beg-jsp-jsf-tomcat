The files *.tag belong to ROOT\WEB-INF\tags\
The files *.jsp belong to ROOT\tests\
To use wow.tld, place it in ROOT\WEB-INF\tlds\ and restart Tomcat.
Create the folders tags and tests if they don't already exist.
