Compile MyClass.java and place MyClass.class it %CATALINA_HOME%\webapps\ROOT\WEB-INF\classes\MyClasses\
Restart Tomcat
Place myObj.jsp in %CATALINA_HOME%\webapps\ROOT\tests\
Type in a browser: localhost:8080/tests/myObj.jsp
