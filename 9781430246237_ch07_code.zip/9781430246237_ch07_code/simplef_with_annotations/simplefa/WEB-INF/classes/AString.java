import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.bean.ManagedProperty;

@ManagedBean(name="aStringBean")
@SessionScoped
public class AString {
  @ManagedProperty(value="#{AString.str}")
  String str;
  public String getStr() { return str; }
  public void setStr(String s) { str = s; }
  }