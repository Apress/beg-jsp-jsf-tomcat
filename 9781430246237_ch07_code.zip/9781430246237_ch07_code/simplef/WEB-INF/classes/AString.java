import java.io.Serializable;
public class AString implements Serializable {
  String str;
  public String getStr() { return str; }
  public void setStr(String s) { str = s; }
  }