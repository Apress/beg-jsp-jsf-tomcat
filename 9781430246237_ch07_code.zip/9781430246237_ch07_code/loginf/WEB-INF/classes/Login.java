import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
@ManagedBean(name="loginBean")
@SessionScoped
public class Login {
  private String user = "";
  public String getUser() { return user; }
  public void setUser(String u) { user = u; }

  private String pass = "";
  public String getPass() { return pass; }
  public void setPass(String p) { pass = p; }

  public String getMess() {
    String mess = "";
    if (user.length() * pass.length() > 0) {
      mess = "Welcome " + user + "!";
      }
    else if (pass.length() > 0) {
      if (user.length() == 0) mess = "Who the hell are you?";
      }
    else {
      if (user.length() > 0) mess = "No password " + user + "?";
      }
    return mess;
    }
  }