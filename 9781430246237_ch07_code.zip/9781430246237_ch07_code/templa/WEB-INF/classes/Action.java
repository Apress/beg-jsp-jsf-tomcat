import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.event.ActionEvent;
@ManagedBean(name="actionBean")
@SessionScoped
public class Action {
  int n = 3;
  public int getN() { return 5 - n; }
  public String goThere() { return "go" + n; }
  public void swapPages(ActionEvent event) { n = 5 - n; }
  }
