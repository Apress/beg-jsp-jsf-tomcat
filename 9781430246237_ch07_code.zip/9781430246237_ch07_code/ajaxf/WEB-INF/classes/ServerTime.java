import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.bean.ManagedProperty;
import java.util.GregorianCalendar;
@ManagedBean(name="serverTimeBean")
@SessionScoped
public class ServerTime {
  @ManagedProperty(value="#{ServerTime.when}")
  private String when;
  public ServerTime() { when = new GregorianCalendar().getTime().toString(); }
  public String getWhen() { return new GregorianCalendar().getTime().toString(); }
  public void setWhen(String w) { when = w; }
  }